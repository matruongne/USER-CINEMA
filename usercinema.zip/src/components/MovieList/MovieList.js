import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { getAllMoviesAsync, selectMovieStatus } from '../../redux/Slices/Movie/movieSlice'

const MovieGrid = ({ movies, onClick }) => (
	<div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
		{movies.map(movie => (
			<div
				key={movie.movie_id}
				className="relative bg-gray-800 rounded-xl shadow-md overflow-hidden group cursor-pointer"
				onClick={() => onClick(movie)}
			>
				<div className="w-full aspect-[2/3] overflow-hidden">
					<img
						src={movie.poster_url}
						alt={movie.title}
						className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
					/>
				</div>
				<div className="absolute inset-0 bg-black bg-opacity-60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 p-4 flex flex-col justify-end">
					<h3 className="text-lg font-bold text-yellow-400 mb-2">{movie.title}</h3>
					<p className="text-sm text-white">
						{movie.duration} phút • {movie.release_date}
					</p>
				</div>
			</div>
		))}
	</div>
)

const MoviesList = () => {
	const navigate = useNavigate()
	const dispatch = useDispatch()
	const status = useSelector(selectMovieStatus)

	const [nowShowing, setNowShowing] = useState([])
	const [comingSoon, setComingSoon] = useState([])

	const [nowPage, setNowPage] = useState(1)
	const [soonPage, setSoonPage] = useState(1)

	const [nowDone, setNowDone] = useState(false)
	const [soonDone, setSoonDone] = useState(false)

	const today = new Date()

	const handleBooking = movie => {
		navigate(`/booking/${movie.movie_id}`)
	}

	useEffect(() => {
		const fetchNowShowing = async () => {
			const { payload } = await dispatch(getAllMoviesAsync({ page: nowPage, limit: 4 }))
			if (!payload) return

			const filtered = payload.items.filter(m => new Date(m.release_date) <= today)

			setNowShowing(prev => {
				const newMovies = filtered.filter(
					m => !prev.some(existing => existing.movie_id === m.movie_id)
				)
				return [...prev, ...newMovies]
			})

			if (payload.items.length === 0) setNowDone(true)
		}
		fetchNowShowing()
	}, [nowPage, dispatch])

	useEffect(() => {
		const fetchComingSoon = async () => {
			const { payload } = await dispatch(getAllMoviesAsync({ page: soonPage, limit: 4 }))
			if (!payload) return

			const filtered = payload.items.filter(m => new Date(m.release_date) > today)

			setComingSoon(prev => {
				const newMovies = filtered.filter(
					m => !prev.some(existing => existing.movie_id === m.movie_id)
				)
				return [...prev, ...newMovies]
			})

			if (payload.items.length === 0) setSoonDone(true)
		}
		fetchComingSoon()
	}, [soonPage, dispatch])

	const handleLoadMoreNow = () => setNowPage(p => p + 1)
	const handleLoadMoreSoon = () => setSoonPage(p => p + 1)

	return (
		<div className="container mx-auto px-4 py-8">
			<h2 className="text-2xl font-bold text-white mb-6">Phim Đang Chiếu</h2>
			<MovieGrid movies={nowShowing} onClick={handleBooking} />
			{!nowDone && (
				<div className="text-center mt-4">
					<button
						onClick={handleLoadMoreNow}
						disabled={status === 'loading'}
						className="bg-primary text-white px-6 py-3 rounded-md text-lg font-semibold hover:bg-primary/80 disabled:opacity-50"
					>
						{status === 'loading' ? 'Đang tải...' : 'Tải thêm'}
					</button>
				</div>
			)}

			<h2 className="text-2xl font-bold text-white mt-12 mb-6">Phim Sắp Chiếu</h2>
			<MovieGrid movies={comingSoon} onClick={handleBooking} />
			{!soonDone && (
				<div className="text-center mt-4">
					<button
						onClick={handleLoadMoreSoon}
						disabled={status === 'loading'}
						className="bg-primary text-white px-6 py-3 rounded-md text-lg font-semibold hover:bg-primary/80 disabled:opacity-50"
					>
						{status === 'loading' ? 'Đang tải...' : 'Tải thêm'}
					</button>
				</div>
			)}
		</div>
	)
}

export default MoviesList
