const services = [
    {
      id: 1,
      name: "Thuê rạp tổ chức sự kiện",
      description: "Dịch vụ thuê rạp để tổ chức hội nghị, sự kiện, sinh nhật...",
      image: "/images/rent-event.jpg",
    },
    {
      id: 2,
      name: "Thuê rạp chiếu phim riêng",
      description: "Dịch vụ chiếu phim riêng tư dành cho nhóm bạn hoặc gia đình.",
      image: "/images/rent-private.jpg",
    },
  ];
  
  export default services;
  