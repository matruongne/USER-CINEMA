const about = {
	title: 'Giới thiệu về BookingCinema',
	description:
		'BookingCinema là hệ thống rạp chiếu phim hiện đại, mang đến những trải nghiệm điện ảnh tốt nhất. Với hệ thống âm thanh Dolby Atmos và màn hình IMAX, BookingCinema hứa hẹn sẽ là điểm đến lý tưởng cho mọi tín đồ phim ảnh.',
	image: '/images/about-bookingcinema.jpg',
}

export default about
