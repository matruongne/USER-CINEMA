const concessions = [
    {
      id: 1,
      name: "Combo 1: Bắp + 1 nước",
      price: 99000,
      image: "/images/combo1.jpg",
    },
    {
      id: 2,
      name: "Combo 2: Bắp + 2 nước",
      price: 119000,
      image: "/images/combo2.jpg",
    },
  ];
  
  export default concessions;
  