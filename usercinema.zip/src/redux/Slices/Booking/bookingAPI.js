import axios from 'axios'

const BASE_URL = 'http://localhost:3051/v1'

export function holdSeatsAPI(showtimeId, data) {
	return axios.post(`${BASE_URL}/bookings/hold/${showtimeId}`, data, {
		withCredentials: true,
	})
}

export function createBookingAPI(showtimeId, data) {
	return axios.post(`${BASE_URL}/bookings/new/${showtimeId}`, data, {
		withCredentials: true,
	})
}
